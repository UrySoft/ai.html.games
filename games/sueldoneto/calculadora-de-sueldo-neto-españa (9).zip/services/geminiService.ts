import { GoogleGenAI } from "@google/genai";
import { SalaryBreakdown, CalculationResult } from '../types';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const jsonStructure = `{
    "grossAnnual": number, "netAnnual": number, "irpfAnnual": number, "irpfStateAnnual": number,
    "irpfCommunityAnnual": number, "employeeSocialSecurityAnnual": number, "employerSocialSecurityAnnual": number,
    "totalCompanyCostAnnual": number, "netMonthly": number
}`;

const parseJsonResponse = (responseText: string): SalaryBreakdown => {
    let jsonStr = responseText.trim();
    const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
    const match = jsonStr.match(fenceRegex);
    if (match && match[2]) {
        jsonStr = match[2].trim();
    }
    
    const parsedData = JSON.parse(jsonStr) as SalaryBreakdown;

    if (parsedData && typeof parsedData.netAnnual === 'number') {
        return parsedData;
    }

    throw new Error("Invalid data structure received from API");
};

const performSingleCalculation = async (grossSalary: number, community: string): Promise<SalaryBreakdown> => {
    const prompt = `
        You are an expert financial advisor specializing in Spanish payroll and taxes for the year 2024.
        The user has provided a gross annual salary of: ${grossSalary} euros.
        The user resides in the autonomous community of: ${community}.
        Assume a standard employment contract for a single person under 30 with no children or disabilities.

        Calculate a standard salary breakdown. The IRPF (Personal Income Tax) must be calculated considering the specific tax brackets for ${community}, split into a state portion ('tramo estatal') and an autonomous community portion ('tramo autonómico').

        Calculate:
        1.  **Gross Annual Salary**: The input value.
        2.  **Total Annual IRPF**: Sum of state and community portions.
        3.  **Annual IRPF (State Portion)**.
        4.  **Annual IRPF (Community Portion)**.
        5.  **Total Annual Employee Social Security Contributions**: Approx. 6.45% of gross, capped.
        6.  **Total Annual Employer Social Security Contributions**: Approx. 31.6% of gross, capped.
        7.  **Net Annual Salary**: Gross Annual - Total IRPF - Employee SS.
        8.  **Total Annual Company Cost**: Gross Annual + Employer SS.
        9.  **Net Monthly Salary**: Net Annual / 12.

        Return the response ONLY as a single, valid JSON object. The JSON object must have the structure: ${jsonStructure}
        Make sure all values are numbers, without currency symbols or thousand separators. Use '.' as the decimal separator.
    `;

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash-preview-04-17",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                temperature: 0.1,
            }
        });
        return parseJsonResponse(response.text);
    } catch (error) {
        console.error("Error in performSingleCalculation or parsing response:", error);
        throw new Error("Failed to get salary breakdown from Gemini API.");
    }
};


const performHypothesisCalculation = async (newGrossSalary: number, community: string): Promise<SalaryBreakdown> => {
    const prompt = `
        You are an expert financial advisor specializing in Spanish payroll and taxes for the year 2024.
        This is a hypothetical calculation.
        The user's new gross annual salary is: ${newGrossSalary} euros. This amount represents the total investment a company would have made in a standard scenario (initial gross salary + employer social security).
        The user resides in the autonomous community of: ${community}.
        Assume a standard employment contract for a single person under 30 with no children or disabilities.

        Your task is to calculate the salary breakdown based on this new gross salary, with one critical rule:
        **The Employer Social Security contribution is ZERO.** The company makes no additional contribution because its original contribution is already included in the new gross salary.

        Calculate:
        1.  **Gross Annual Salary**: The input value (${newGrossSalary}).
        2.  **Employer Social Security Contributions**: This MUST be 0.
        3.  **Total Annual Employee Social Security Contributions**: Calculate this based on the new gross salary (Approx. 6.45% of gross, capped).
        4.  **Total Annual IRPF**: Calculate this based on the new gross salary. It must be split into a state portion ('tramo estatal') and an autonomous community portion ('tramo autonómico') for ${community}.
        5.  **Annual IRPF (State Portion)**.
        6.  **Annual IRPF (Community Portion)**.
        7.  **Net Annual Salary**: New Gross Annual - Total IRPF - Employee SS.
        8.  **Total Annual Company Cost**: This will be equal to the New Gross Annual Salary, as Employer SS is 0.
        9.  **Net Monthly Salary**: Net Annual / 12.

        Return the response ONLY as a single, valid JSON object. The JSON object must have the structure: ${jsonStructure}
        Make sure all values are numbers, without currency symbols or thousand separators. Use '.' as the decimal separator.
    `;

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash-preview-04-17",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                temperature: 0.1,
            }
        });
        return parseJsonResponse(response.text);
    } catch (error) {
        console.error("Error in performHypothesisCalculation or parsing response:", error);
        throw new Error("Failed to get salary breakdown for hypothesis from Gemini API.");
    }
}

export const calculateSalaryBreakdown = async (
    grossSalary: number, 
    community: string, 
    onProgress: (key: string, values?: Record<string, string | number>) => void
): Promise<CalculationResult> => {

    onProgress("progress.standard");
    const standardResult = await performSingleCalculation(grossSalary, community);

    const newGrossSalary = standardResult.totalCompanyCostAnnual;
    onProgress("progress.hypothesis", { 
      amount: newGrossSalary.toLocaleString('es-ES', { style: 'currency', currency: 'EUR' }) 
    });
    const hypothesisResult = await performHypothesisCalculation(newGrossSalary, community);
    
    onProgress("progress.done");

    return {
        standard: standardResult,
        companyCostAsGross: hypothesisResult
    };
};